package com.trackmyspend.companion

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayoutMediator
import com.trackmyspend.companion.databinding.ActivityMainBinding
import com.trackmyspend.companion.databinding.DialogBackfillSettingsBinding
import com.trackmyspend.companion.databinding.DialogUpdateManifestUrlBinding
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsStore
    private val executor = Executors.newSingleThreadExecutor()
    private val backfillRunning = AtomicBoolean(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        updatePermissionBanner()
        recoverMissedSms()
    }

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) exportOutbox() else {
            Snackbar.make(binding.root, R.string.storage_permission_needed, Snackbar.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsStore(this)
        if (BuildConfig.DEBUG) ReliabilitySelfCheck.run()

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { showToolbarMenu() }
        binding.grantPermissionButton.setOnClickListener { requestSmsPermissionsIfNeeded() }

        val adapter = MainPagerAdapter(this)
        binding.viewPager.adapter = adapter
        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> getString(R.string.tab_filters)
                1 -> getString(R.string.tab_servers)
                else -> getString(R.string.tab_log)
            }
        }.attach()

        requestSmsPermissionsIfNeeded()
        recoverMissedSms()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionBanner()
    }

    fun startBackfill(source: BackfillSource) {
        if (!hasSmsPermissions()) {
            Snackbar.make(binding.root, R.string.backfill_no_permission, Snackbar.LENGTH_LONG).show()
            return
        }
        if (!backfillRunning.compareAndSet(false, true)) return
        setBackfillLoading(true)
        executor.execute {
            val result = InboxBackfill.run(this, source)
            runOnUiThread {
                backfillRunning.set(false)
                setBackfillLoading(false)
                showBackfillResult(result)
            }
        }
    }

    private fun recoverMissedSms() {
        UploadWorker.enqueueAllPending(this)
        if (!hasSmsPermissions()) return
        if (MessageStore(this).isEmpty()) return
        startBackfill(BackfillSource.ON_OPEN)
    }

    private fun setBackfillLoading(loading: Boolean) {
        binding.backfillOverlay.visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun showBackfillResult(result: BackfillResult) {
        if (result.skipped) return
        val sourceLabel = when (result.source) {
            BackfillSource.AFTER_SERVER_SAVE -> "save"
            BackfillSource.ON_OPEN -> "open"
            BackfillSource.MANUAL -> "manual"
        }
        val text = when {
            result.error != null && result.watermarkUsed ->
                getString(R.string.backfill_watermark_failed)
            result.error != null ->
                result.error
            result.hitCap ->
                getString(R.string.backfill_done_cap, sourceLabel, result.enqueued)
            else ->
                getString(R.string.backfill_done, sourceLabel, result.enqueued)
        }
        Snackbar.make(binding.root, text, Snackbar.LENGTH_LONG).show()
    }

    private fun hasSmsPermissions(): Boolean = SMS_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun showToolbarMenu() {
        PopupMenu(this, binding.toolbar).apply {
            menu.add(0, MENU_PULL_SMS, 0, R.string.menu_pull_sms)
            menu.add(0, MENU_BACKFILL_SETTINGS, 1, R.string.menu_backfill_settings)
            menu.add(0, MENU_EXPORT_OUTBOX, 2, R.string.menu_export_outbox)
            menu.add(0, MENU_CHECK_UPDATES, 3, R.string.menu_check_updates)
            menu.add(0, MENU_UPDATE_MANIFEST_URL, 4, R.string.menu_update_manifest_url)
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    MENU_PULL_SMS -> {
                        startBackfill(BackfillSource.MANUAL)
                        true
                    }
                    MENU_BACKFILL_SETTINGS -> {
                        showBackfillSettingsDialog()
                        true
                    }
                    MENU_EXPORT_OUTBOX -> {
                        requestExportOutbox()
                        true
                    }
                    MENU_CHECK_UPDATES -> {
                        checkForUpdates()
                        true
                    }
                    MENU_UPDATE_MANIFEST_URL -> {
                        showUpdateManifestUrlDialog()
                        true
                    }
                    else -> false
                }
            }
        }.show()
    }

    private fun showBackfillSettingsDialog() {
        val dialogBinding = DialogBackfillSettingsBinding.inflate(layoutInflater)
        dialogBinding.lookbackInput.setText(prefs.getBackfillLookbackHours().toString())
        dialogBinding.maxRowsInput.setText(prefs.getBackfillMaxRows().toString())
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.backfill_settings_title)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.save) { _, _ ->
                val hours = dialogBinding.lookbackInput.text?.toString()?.toIntOrNull()
                val rows = dialogBinding.maxRowsInput.text?.toString()?.toIntOrNull()
                if (hours == null || rows == null) {
                    Snackbar.make(binding.root, R.string.backfill_settings_invalid, Snackbar.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                prefs.setBackfillLookbackHours(hours)
                prefs.setBackfillMaxRows(rows)
                Snackbar.make(binding.root, R.string.backfill_settings_saved, Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun requestExportOutbox() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            exportOutbox()
            return
        }
        val granted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            exportOutbox()
        } else {
            storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    private fun exportOutbox() {
        Snackbar.make(binding.root, R.string.export_started, Snackbar.LENGTH_SHORT).show()
        executor.execute {
            val result = runCatching { OutboxExporter.exportToDownloads(this) }
            runOnUiThread {
                result.fold(
                    onSuccess = { name ->
                        Snackbar.make(
                            binding.root,
                            getString(R.string.export_done, name),
                            Snackbar.LENGTH_LONG,
                        ).show()
                    },
                    onFailure = { error ->
                        Snackbar.make(
                            binding.root,
                            getString(R.string.export_failed, error.message ?: error.javaClass.simpleName),
                            Snackbar.LENGTH_LONG,
                        ).show()
                    },
                )
            }
        }
    }

    private fun showUpdateManifestUrlDialog() {
        val dialogBinding = DialogUpdateManifestUrlBinding.inflate(layoutInflater)
        prefs.getUpdateManifestUrl()?.let { dialogBinding.urlInput.setText(it) }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.update_manifest_url_title)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.save) { _, _ ->
                val url = dialogBinding.urlInput.text?.toString().orEmpty()
                prefs.setUpdateManifestUrl(url)
                Snackbar.make(binding.root, R.string.update_manifest_url_saved, Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun checkForUpdates() {
        val manifestUrl = prefs.getUpdateManifestUrl()
        if (manifestUrl.isNullOrBlank()) {
            Snackbar.make(binding.root, R.string.update_manifest_url_not_set, Snackbar.LENGTH_LONG).show()
            return
        }
        Snackbar.make(binding.root, R.string.update_checking, Snackbar.LENGTH_SHORT).show()
        executor.execute {
            val result = runCatching {
                val manifest = UpdateChecker.fetchManifest(manifestUrl)
                val installedCode = UpdateChecker.getInstalledVersionCode(this)
                UpdateChecker.compare(installedCode, manifest)
            }.getOrElse { CompareResult.Error(it.message ?: it.javaClass.simpleName) }
            runOnUiThread { handleCompareResult(result) }
        }
    }

    private fun handleCompareResult(result: CompareResult) {
        when (result) {
            is CompareResult.UpToDate -> {
                Snackbar.make(
                    binding.root,
                    getString(R.string.update_up_to_date, BuildConfig.VERSION_NAME),
                    Snackbar.LENGTH_LONG,
                ).show()
            }
            is CompareResult.Error -> {
                Snackbar.make(binding.root, result.message, Snackbar.LENGTH_LONG).show()
            }
            is CompareResult.UpdateAvailable -> showUpdateDialog(result)
        }
    }

    private fun showUpdateDialog(result: CompareResult.UpdateAvailable) {
        val manifest = result.manifest
        val installedCode = UpdateChecker.getInstalledVersionCode(this).toInt()
        val body = buildString {
            append(
                getString(
                    R.string.update_dialog_body,
                    BuildConfig.VERSION_NAME,
                    installedCode,
                    manifest.versionName,
                    manifest.versionCode,
                )
            )
            manifest.changelog?.let {
                append("\n\n")
                append(getString(R.string.update_changelog, it))
            }
            if (!result.isUpgrade) {
                append("\n\n")
                append(getString(R.string.update_downgrade_warning))
            }
        }
        val title = if (result.isUpgrade) R.string.update_available_title else R.string.update_downgrade_title
        val confirm = if (result.isUpgrade) R.string.update_confirm else R.string.update_confirm_downgrade
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage(body)
            .setPositiveButton(confirm) { _, _ -> downloadAndInstall(manifest.apkUrl) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun downloadAndInstall(apkUrl: String) {
        Snackbar.make(binding.root, R.string.update_downloading, Snackbar.LENGTH_SHORT).show()
        executor.execute {
            val downloadResult = runCatching {
                UpdateChecker.downloadApk(apkUrl, cacheDir)
            }
            runOnUiThread {
                downloadResult.fold(
                    onSuccess = { apkFile ->
                        runCatching { UpdateChecker.launchInstall(this, apkFile) }
                            .onFailure { e ->
                                Snackbar.make(
                                    binding.root,
                                    e.message ?: e.javaClass.simpleName,
                                    Snackbar.LENGTH_LONG,
                                ).show()
                            }
                    },
                    onFailure = { e ->
                        Snackbar.make(
                            binding.root,
                            e.message ?: e.javaClass.simpleName,
                            Snackbar.LENGTH_LONG,
                        ).show()
                    },
                )
            }
        }
    }

    private fun requestSmsPermissionsIfNeeded() {
        val missing = SMS_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
        updatePermissionBanner()
    }

    private fun updatePermissionBanner() {
        binding.permissionBanner.visibility = if (hasSmsPermissions()) View.GONE else View.VISIBLE
    }

    companion object {
        private const val MENU_PULL_SMS = 0
        private const val MENU_BACKFILL_SETTINGS = 1
        private const val MENU_EXPORT_OUTBOX = 2
        private const val MENU_CHECK_UPDATES = 3
        private const val MENU_UPDATE_MANIFEST_URL = 4

        private val SMS_PERMISSIONS = arrayOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
        )
    }
}
